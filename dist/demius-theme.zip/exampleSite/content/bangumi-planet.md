---
title: "追番星球"
slug: bangumi-planet
date: 2025-10-31T12:00:00+08:00
lastmod: 2025-10-31T12:00:00+08:00
draft: false
type: bangumi-planet
layout: bangumi-planet
description: "我的追番追剧列表，记录看过的、在看的和想看的番剧/影视作品。"
---

## 追番星球

这里是我在B站追番追剧的记录，包括想看、在看和看过的作品。数据来源于B站个人追番列表。
