---
title: "音乐星球"
slug: music-planet
date: 2025-10-30T12:00:00+08:00
lastmod: 2025-10-30T12:00:00+08:00
type: music-planet
layout: music-planet
description: "不同平台的歌单与专辑分享，支持网易云、QQ音乐等。"
---




