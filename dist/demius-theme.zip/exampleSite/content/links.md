---
title: "友链"
date: 2025-10-18T17:00:00+08:00
type: "links"
layout: "links"
comments: true
---

## 友链申请

麻烦请先添加本站友链，按照下面的模板在评论区留言，我会及时的审核，审核通过后会添加到友链中，如果有问题，请留言，我会及时的回复。

已经添加的友链本站会不定时回访，如本站被下友链，请及时的通知我，我会及时的删除贵方的友链，如未通知本站即下友链，本站将视为无效友链，不予添加。

本站主动添加的友链，两周内如未加友链，本站将视为无效友链，不予添加。




```yaml
- name: "字·兮·书"
        url: "https://blog.demius.tech"
        avatar: "/img/avatar.png"
        description: "时间就是生命，Life is money，Money is life"
        tags: ["技术"]
        rss: "https://blog.demius.tech/index.xml"
```